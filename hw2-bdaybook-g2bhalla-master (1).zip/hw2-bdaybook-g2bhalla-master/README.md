# bdaybook
Empty files for the Birthday Book Manager SQL questions
