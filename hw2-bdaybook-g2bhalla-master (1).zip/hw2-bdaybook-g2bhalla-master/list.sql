-- Name: YourNameHere
-- WatIAM username: IDhere
-- 
-- Details: This file demonstrates how to query the bdaybook to
--          list all birthdays.
--          
-- Warning: Read the homework for detailed instructions.
USE bdaybook;
SELECT * FROM bdaybookmanager;