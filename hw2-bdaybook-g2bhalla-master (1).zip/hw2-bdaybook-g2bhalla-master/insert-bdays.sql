-- Name: Gunchica Bhalla 
-- WatIAM username: g2bhalla
-- 
-- Details: This file inserts some example data into the database.
--          Example data can be used for testing other SQL queries
--          and/or testing an actual application.
--          
-- Warning: Read the homework for detailed instructions.
USE bdaybook;
INSERT INTO bdaybookmanager (first_name,last_name,day,month,birth_year)
VALUES(('Madonna','Ciccone', I 16,8,1958),('William','Gates',28,10,1955),('Natalie','Hershlag',9,6,1981),('Lawrence','Ellison',17,8,1944),('William','Pitt',18,12,1963),('Michael','Stonebraker',11,10,1943),('Gunchica','Bhalla',8,8,1999));