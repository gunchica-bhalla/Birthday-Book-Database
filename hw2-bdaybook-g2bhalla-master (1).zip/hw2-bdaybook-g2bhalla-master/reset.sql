-- Name: Gunchica Bhalla
-- WatIAM username: g2bhalla
-- 
-- Details: This file resets the database.
--          
-- Warning: Read the homework for detailed instructions.
USE bdaybook;
DROP TABLE bdaybookmanager;
DROP DATABASE bdaybook;